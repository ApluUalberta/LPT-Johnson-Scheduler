Submission of Assignment 3: The Readme file

Submitting Student: Allen Lu

Student ID: 1498902

Collaborating Students: Ali Reza Mosavi, Ankush Sharma, Hyeon Yu

No References



compilation process:
gcc -Wall -std=c99 assignment3.c

./a.out -r

Whole program takes about 20 minutes to do everything, about 10 minutes for the reading and generating of result.txt..

./a.out -i < testcase.txt

This -i only takes input through directing text files into the -i instance. I chose to not implement scanf. So if you compile without redirecting text files, then the -i process will just read blank...

